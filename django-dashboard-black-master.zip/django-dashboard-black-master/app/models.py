# -*- encoding: utf-8 -*-
"""
License: MIT
Copyright (c) 2019 - present AppSeed.us
"""

from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class Country(models.Model):
    idcountry=models.IntegerField(primary_key=True)
    country = models.CharField(max_length=220)
    count = models.CharField(max_length=220)

    class Meta:
        db_table = 'country'