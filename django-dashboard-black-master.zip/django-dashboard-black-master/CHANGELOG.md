# Change Log

## Unreleased
### 2020-09-10

- Patch - Current page is now visible in the sidebar menu

